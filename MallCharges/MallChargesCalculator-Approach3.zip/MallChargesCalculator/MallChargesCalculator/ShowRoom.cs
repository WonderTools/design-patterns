﻿namespace MallChargesCalculator
{
    public class ShowRoom : IRentable
    {
        public int Id { get; set; }

        public int AreaInSquareFeet { get; set; }
    }
}