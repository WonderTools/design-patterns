﻿namespace MallChargesCalculator
{
    public class AdvertisementBoard : IRentable
    {
        public int Id { get; set; }
        public int AreaInSquareFeet { get; set; }
    }
}