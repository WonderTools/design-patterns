﻿using System;
using MallChargesCalculator.ChargeCalculation;

namespace MallChargesCalculator
{
    public class ChargesCalculatingFacade
    {
        RentableRepository _rentableRepository = new RentableRepository();

        public void DisplayRentingCharges(int id)
        {
            var rentable = _rentableRepository.GetRentableOrNull(id);
            if (rentable == null)
            {
                Console.WriteLine("The item is not found");
                return;
            }
            Console.WriteLine("The Item is " + rentable.GetType().Name);
            Console.WriteLine("The Id is " + rentable.Id);
            var chargeCalculator = ChargeCalculatorFactory.GetChargeCalculator(rentable); 
            Console.WriteLine("The Renting Charges are " + chargeCalculator.GetRentingCharges());
            Console.WriteLine("The Electricity Charges are " + chargeCalculator.GetElectricityCharges());
            Console.WriteLine("The Water Charges are " + chargeCalculator.GetWaterCharges());
            Console.WriteLine("The Cleaning Charges are " + chargeCalculator.GetCleaningCharges());
        }
    }
}