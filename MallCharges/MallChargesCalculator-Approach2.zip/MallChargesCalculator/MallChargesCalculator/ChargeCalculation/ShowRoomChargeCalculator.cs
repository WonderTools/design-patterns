﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class ShowRoomChargeCalculator : IChargeCalculator
    {
        private readonly ShowRoom _showRoom;

        public ShowRoomChargeCalculator(ShowRoom showRoom)
        {
            _showRoom = showRoom;
        }
        public int GetRentingCharges()
        {
            return _showRoom.AreaInSquareFeet * 80;
        }

        public int GetWaterCharges()
        {
            return _showRoom.AreaInSquareFeet * 4;
        }

        public int GetElectricityCharges()
        {
            return _showRoom.AreaInSquareFeet * 3;
        }

        public int GetCleaningCharges()
        {
            return _showRoom.AreaInSquareFeet * 1;
        }
    }
}