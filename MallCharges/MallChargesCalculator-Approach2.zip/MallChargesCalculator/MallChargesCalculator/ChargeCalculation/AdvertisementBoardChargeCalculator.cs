﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class AdvertisementBoardChargeCalculator : IChargeCalculator
    {
        private readonly AdvertisementBoard _advertisementBoard;

        public AdvertisementBoardChargeCalculator(AdvertisementBoard advertisementBoard)
        {
            _advertisementBoard = advertisementBoard;
        }
        public int GetRentingCharges()
        {
            return _advertisementBoard.AreaInSquareFeet * 3;
        }

        public int GetWaterCharges()
        {
            return 0;
        }

        public int GetElectricityCharges()
        {
            return _advertisementBoard.AreaInSquareFeet * 10;
        }

        public int GetCleaningCharges()
        {
            return 50;
        }
    }
}