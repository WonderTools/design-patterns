﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class TheaterChargeCalculator : IChargeCalculator
    {
        private readonly Theater _theater;

        public TheaterChargeCalculator(Theater theater)
        {
            _theater = theater;
        }
        public int GetRentingCharges()
        {
           return _theater.SeatingCapacity * 800 + 1000;
        }

        public int GetWaterCharges()
        {
            return _theater.SeatingCapacity * 2 + 100;
        }

        public int GetElectricityCharges()
        {
            return _theater.SeatingCapacity * 5 + 5000;
        }

        public int GetCleaningCharges()
        {
            return _theater.SeatingCapacity * 10;
        }
    }
}