﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MallChargesCalculator.ChargeCalculation
{
    class EateryChargeCalculator : IChargeCalculator
    {
        private readonly Eatery _eatery;

        public EateryChargeCalculator(Eatery eatery)
        {
            _eatery = eatery;
        }
        public int GetRentingCharges()
        {
            return _eatery.SeatingCapacity * 400 + 10000;
        }

        public int GetWaterCharges()
        {
            return _eatery.SeatingCapacity * 10 + 1000;
        }

        public int GetElectricityCharges()
        {
            return _eatery.SeatingCapacity * 6 + 1000;
        }

        public int GetCleaningCharges()
        {
            return _eatery.SeatingCapacity * 25;
        }
    }
}
