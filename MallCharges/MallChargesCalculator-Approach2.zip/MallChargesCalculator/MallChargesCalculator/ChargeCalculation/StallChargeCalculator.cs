﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class StallChargeCalculator : IChargeCalculator
    {
        private readonly Stall _stall;

        public StallChargeCalculator(Stall stall)
        {
            _stall = stall;
        }
        public int GetRentingCharges()
        {
            return _stall.AreaInSquareFeet * 200;
        }

        public int GetWaterCharges()
        {
            return _stall.AreaInSquareFeet * 6;
        }

        public int GetElectricityCharges()
        {
            return _stall.AreaInSquareFeet * 5;
        }

        public int GetCleaningCharges()
        {
            return _stall.AreaInSquareFeet * 1;
        }
    }
}