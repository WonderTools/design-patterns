﻿namespace MallChargesCalculator.ChargeCalculation
{
    public interface IChargeCalculator
    {
        int GetRentingCharges();

        int GetWaterCharges();

        int GetElectricityCharges();

        int GetCleaningCharges();
    }
}