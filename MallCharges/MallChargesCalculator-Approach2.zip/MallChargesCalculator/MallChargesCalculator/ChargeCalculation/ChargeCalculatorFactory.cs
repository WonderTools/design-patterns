﻿namespace MallChargesCalculator.ChargeCalculation
{
    public static class ChargeCalculatorFactory
    {
        public static IChargeCalculator GetChargeCalculator(IRentable rentable)
        {
            var type = rentable.GetType();
            if (type == typeof(AdvertisementBoard))
                return new AdvertisementBoardChargeCalculator(rentable as AdvertisementBoard);
            if (rentable.GetType() == typeof(Eatery)) return new EateryChargeCalculator(rentable as Eatery);
            if (rentable.GetType() == typeof(FoodCourt)) return new FoodCourtChargeCalculator(rentable as FoodCourt);
            if (rentable.GetType() == typeof(Multiplex)) return new MultiplexChargeCalculator(rentable as Multiplex);
            if (rentable.GetType() == typeof(Parking)) return new ParkingChargeCalculator(rentable as Parking);
            if (rentable.GetType() == typeof(ShowRoom)) return new ShowRoomChargeCalculator(rentable as ShowRoom);
            if (rentable.GetType() == typeof(Stall)) return new StallChargeCalculator(rentable as Stall);
            if (rentable.GetType() == typeof(Theater)) return new TheaterChargeCalculator(rentable as Theater);
            return new AdvertisementBoardChargeCalculator(rentable as AdvertisementBoard);
        }
    }
}