﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class MultiplexChargeCalculator : IChargeCalculator
    {
        private readonly Multiplex _multiplex;

        public MultiplexChargeCalculator(Multiplex multiplex)
        {
            _multiplex = multiplex;
        }
        public int GetRentingCharges()
        {
           return _multiplex.TotalSeatingCapacity * 700 + _multiplex.NumberOfScreens * 1000;
        }

        public int GetWaterCharges()
        {
            return _multiplex.TotalSeatingCapacity * 2 + _multiplex.NumberOfScreens * 80;
        }

        public int GetElectricityCharges()
        {
            return _multiplex.TotalSeatingCapacity * 5 + _multiplex.NumberOfScreens * 5000;
        }

        public int GetCleaningCharges()
        {
            return _multiplex.TotalSeatingCapacity * 10;
        }
    }
}