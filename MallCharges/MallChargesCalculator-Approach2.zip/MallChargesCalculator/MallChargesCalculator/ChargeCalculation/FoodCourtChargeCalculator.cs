﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class FoodCourtChargeCalculator : IChargeCalculator
    {
        private readonly FoodCourt _foodCourt;

        public FoodCourtChargeCalculator(FoodCourt foodCourt)
        {
            _foodCourt = foodCourt;
        }

        public int GetRentingCharges()
        {
            return _foodCourt.NumberOfCounters * 10000 + _foodCourt.SeatingCapacity * 300;
        }

        public int GetWaterCharges()
        {
            return _foodCourt.NumberOfCounters * 100 + _foodCourt.SeatingCapacity + 10;
        }

        public int GetElectricityCharges()
        {
            return _foodCourt.NumberOfCounters * 100 + _foodCourt.SeatingCapacity * 6;
        }

        public int GetCleaningCharges()
        {
            return _foodCourt.SeatingCapacity * 25;
        }
    }
}