﻿namespace MallChargesCalculator.ChargeCalculation
{
    public class ParkingChargeCalculator : IChargeCalculator
    {
        private readonly Parking _parking;

        public ParkingChargeCalculator(Parking parking)
        {
            _parking = parking;
        }
        public int GetRentingCharges()
        {
           return _parking.CarCapacity * 300 + _parking.MotorBikeCapacity * 50;
        }

        public int GetWaterCharges()
        {
            return (int) (_parking.CarCapacity * 1 + _parking.MotorBikeCapacity * .5);
        }

        public int GetElectricityCharges()
        {
            return 1000;
        }

        public int GetCleaningCharges()
        {
            return 2000;
        }
    }
}