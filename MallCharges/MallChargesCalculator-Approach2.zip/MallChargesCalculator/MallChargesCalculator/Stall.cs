﻿namespace MallChargesCalculator
{
    public class Stall : IRentable
    {
        public int AreaInSquareFeet { get; set; }
        public int Id { get; set; }
    }
}