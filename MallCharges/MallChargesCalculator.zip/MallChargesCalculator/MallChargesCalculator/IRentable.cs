﻿namespace MallChargesCalculator
{
    public interface IRentable
    {
        int Id { get; set; }
    }
}