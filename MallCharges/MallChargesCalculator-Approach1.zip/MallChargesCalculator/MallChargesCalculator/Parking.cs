﻿namespace MallChargesCalculator
{
    public class Parking : IRentable
    {
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return CarCapacity * 300 + MotorBikeCapacity * 50;
        }

        public int GetWaterCharges()
        {
            return (int) (CarCapacity * 1 + MotorBikeCapacity * .5);
        }

        public int GetElectricityCharges()
        {
            return 1000;
        }

        public int GetCleaningCharges()
        {
            return 2000;
        }

        public int CarCapacity { get; set; }
        public int MotorBikeCapacity { get; set; }
    }
}