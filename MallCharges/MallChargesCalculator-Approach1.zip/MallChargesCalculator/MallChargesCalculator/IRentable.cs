﻿namespace MallChargesCalculator
{
    public interface IRentable
    {
        int Id { get; set; }

        int GetRentingCharges();

        int GetWaterCharges();

        int GetElectricityCharges();

        int GetCleaningCharges();
    }
}