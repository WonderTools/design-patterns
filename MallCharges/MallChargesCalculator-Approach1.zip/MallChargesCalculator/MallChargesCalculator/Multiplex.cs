﻿namespace MallChargesCalculator
{
    public class Multiplex : IRentable
    {
        public int TotalSeatingCapacity { get; set; }
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return TotalSeatingCapacity * 700 + NumberOfScreens * 1000;
        }

        public int GetWaterCharges()
        {
            return TotalSeatingCapacity * 2 + NumberOfScreens * 80;
        }

        public int GetElectricityCharges()
        {
            return TotalSeatingCapacity * 5 + NumberOfScreens * 5000;
        }

        public int GetCleaningCharges()
        {
            return TotalSeatingCapacity * 10;
        }

        public int NumberOfScreens { get; set; }
    }
}