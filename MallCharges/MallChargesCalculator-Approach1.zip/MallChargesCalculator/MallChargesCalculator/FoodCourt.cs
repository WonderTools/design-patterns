﻿namespace MallChargesCalculator
{
    public class FoodCourt : IRentable
    {
        public int NumberOfCounters { get; set; }
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return NumberOfCounters * 10000 + SeatingCapacity * 300;
        }

        public int GetWaterCharges()
        {
            return NumberOfCounters * 100 + SeatingCapacity + 10;
        }

        public int GetElectricityCharges()
        {
            return NumberOfCounters * 100 + SeatingCapacity * 6;
        }

        public int GetCleaningCharges()
        {
            return SeatingCapacity * 25;
        }

        public int SeatingCapacity { get; set; }
    }
}