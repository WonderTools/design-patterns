﻿namespace MallChargesCalculator
{
    public class Stall : IRentable
    {
        public int AreaInSquareFeet { get; set; }
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return AreaInSquareFeet * 200;
        }

        public int GetWaterCharges()
        {
            return AreaInSquareFeet * 6;
        }

        public int GetElectricityCharges()
        {
            return AreaInSquareFeet * 5;
        }

        public int GetCleaningCharges()
        {
            return AreaInSquareFeet * 1;
        }
    }
}