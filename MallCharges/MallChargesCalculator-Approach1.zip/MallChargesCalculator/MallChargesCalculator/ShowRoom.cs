﻿namespace MallChargesCalculator
{
    public class ShowRoom : IRentable
    {
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return AreaInSquareFeet * 80;
        }

        public int GetWaterCharges()
        {
            return AreaInSquareFeet * 4;
        }

        public int GetElectricityCharges()
        {
            return AreaInSquareFeet * 3;
        }

        public int GetCleaningCharges()
        {
            return AreaInSquareFeet * 1;
        }

        public int AreaInSquareFeet { get; set; }
    }
}