﻿namespace MallChargesCalculator
{
    public class AdvertisementBoard : IRentable
    {
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return AreaInSquareFeet * 3;
        }

        public int GetWaterCharges()
        {
            return 0;
        }

        public int GetElectricityCharges()
        {
            return AreaInSquareFeet * 10;
        }

        public int GetCleaningCharges()
        {
            return 50;
        }

        public int AreaInSquareFeet { get; set; }
    }
}