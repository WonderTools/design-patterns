﻿using System;

namespace MallChargesCalculator
{
    public class ChargesCalculatingFacade
    {
        RentableRepository _rentableRepository = new RentableRepository();

        public void DisplayRentingCharges(int id)
        {
            var rentable = _rentableRepository.GetRentableOrNull(id);
            if (rentable == null)
            {
                Console.WriteLine("The item is not found");
                return;
            }
            Console.WriteLine("The Item is " + rentable.GetType().Name);
            Console.WriteLine("The Id is " + rentable.Id);
            Console.WriteLine("The Renting Charges are " + rentable.GetRentingCharges());
            Console.WriteLine("The Electricity Charges are " + rentable.GetElectricityCharges());
            Console.WriteLine("The Water Charges are " + rentable.GetWaterCharges());
            Console.WriteLine("The Cleaning Charges are " + rentable.GetCleaningCharges());
        }

    }
}