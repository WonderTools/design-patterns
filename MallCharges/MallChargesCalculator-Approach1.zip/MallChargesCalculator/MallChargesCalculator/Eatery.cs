﻿namespace MallChargesCalculator
{
    public class Eatery : IRentable
    {
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return SeatingCapacity * 400 + 10000;
        }

        public int GetWaterCharges()
        {
            return SeatingCapacity * 10 + 1000;
        }

        public int GetElectricityCharges()
        {
            return SeatingCapacity * 6 + 1000;
        }

        public int GetCleaningCharges()
        {
            return SeatingCapacity * 25;
        }

        public int SeatingCapacity { get; set; }
    }
}