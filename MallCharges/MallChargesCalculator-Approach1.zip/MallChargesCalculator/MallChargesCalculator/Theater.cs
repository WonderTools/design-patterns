﻿namespace MallChargesCalculator
{
    public class Theater : IRentable
    {
        public int SeatingCapacity { get; set; }
        public int Id { get; set; }
        public int GetRentingCharges()
        {
            return SeatingCapacity * 800 + 1000;
        }

        public int GetWaterCharges()
        {
            return SeatingCapacity * 2 + 100;
        }

        public int GetElectricityCharges()
        {
            return SeatingCapacity * 5 + 5000;
        }

        public int GetCleaningCharges()
        {
            return SeatingCapacity * 10;
        }
    }
}